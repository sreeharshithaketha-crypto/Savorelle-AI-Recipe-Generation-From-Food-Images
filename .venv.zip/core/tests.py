import csv
import io
import json
import zipfile
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import Client, TestCase, override_settings
from PIL import Image

from .ai import _apply_allergy_filters


PROJECT_ROOT = Path(__file__).resolve().parent.parent


class AccountApiTests(TestCase):
    def setUp(self):
        self.client = Client(enforce_csrf_checks=True)
        self.client.get("/api/csrf/")

    def post(self, url, data):
        return self.client.post(
            url,
            data=json.dumps(data),
            content_type="application/json",
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

    def put(self, url, data):
        return self.client.put(
            url,
            data=json.dumps(data),
            content_type="application/json",
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

    def jpeg_upload(self):
        image = io.BytesIO()
        Image.new("RGB", (16, 16), color="white").save(image, format="JPEG")
        return SimpleUploadedFile(
            "scan.jpg", image.getvalue(), content_type="image/jpeg"
        )

    def test_home_serves_current_frontend(self):
        response = self.client.get("/")
        self.assertContains(response, "/assets/styles.css?v=3")
        self.assertContains(response, "/assets/app.js?v=14")
        self.assertContains(response, "Browse the 50 sample recipes (read-only)")
        self.assertContains(response, "Google Gemini")
        self.assertContains(response, "Photo analysis, recipe generation and public YouTube recipe import")
        self.assertContains(response, "Selected allergies and foods to avoid")

    def test_demo_recipe_catalogue_serves_browse_only_source_data(self):
        response = self.client.get("/api/demo-recipes/")

        self.assertEqual(response.status_code, 200)
        recipes = response.json()
        self.assertEqual(len(recipes), 50)
        self.assertEqual(recipes[0]["recipe_id"], "R001")
        self.assertEqual(recipes[0]["recipe_name"], "Vegetable Fried Rice")
        self.assertIsInstance(recipes[0]["ingredients"], list)
        self.assertIsInstance(recipes[0]["instructions"], list)
        self.assertNotIn("ingredient_quantities", recipes[0])

    def test_registration_and_workspace_round_trip(self):
        response = self.post(
            "/api/auth/register/",
            {
                "name": "Savorelle User",
                "username": "savorelle_user",
                "email": "user@example.com",
                "password": "A-safe-password-123",
                "acceptedTerms": True,
            },
        )
        self.assertEqual(response.status_code, 201)
        self.assertTrue(
            get_user_model().objects.get(username="savorelle_user").check_password(
                "A-safe-password-123"
            )
        )

        workspace = {
            "inventory": [{"n": "tomato", "q": 3, "u": "pc"}],
            "favorites": [1],
            "history": [],
            "plan": {},
            "bought": [],
            "allergies": [],
            "avoid": [],
            "preferences": {"diet": "Any", "time": 0, "diff": "Any"},
            "calories": {"t": 2000, "strict": True},
            "notes": {},
            "customRecipes": [],
        }
        response = self.put("/api/workspace/", {"revision": 0, "data": workspace})
        self.assertEqual(response.status_code, 200)
        response = self.client.get("/api/workspace/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["data"]["inventory"], workspace["inventory"])
        self.assertEqual(response.json()["revision"], 1)

    def test_stale_workspace_revision_is_rejected(self):
        self.post(
            "/api/auth/register/",
            {
                "name": "Savorelle User",
                "username": "savorelle_user",
                "email": "user@example.com",
                "password": "A-safe-password-123",
                "acceptedTerms": True,
            },
        )
        self.assertEqual(
            self.put("/api/workspace/", {"revision": 0, "data": {}}).status_code,
            200,
        )
        response = self.put("/api/workspace/", {"revision": 0, "data": {}})
        self.assertEqual(response.status_code, 409)

    def test_custom_recipe_and_recipe_references_round_trip(self):
        self.post(
            "/api/auth/register/",
            {
                "name": "Savorelle User",
                "username": "recipe_user",
                "email": "recipe@example.com",
                "password": "A-safe-password-123",
                "acceptedTerms": True,
            },
        )
        recipe = {
            "id": 9,
            "name": "Chickpea bowl",
            "time": 25,
            "diff": "Easy",
            "diet": "vegan",
            "kcal": 400,
            "pro": 18,
            "ing": [{"n": "chickpea", "q": 200, "u": "g"}],
            "prep": ["Rinse chickpeas."],
            "cook": ["Warm and serve."],
            "src": "",
            "gen": True,
        }
        recipe["versions"] = [
            {
                "savedAt": "2025-01-01T12:00:00.000Z",
                "snapshot": {
                    key: value
                    for key, value in recipe.items()
                    if key not in {"id", "versions"}
                },
            }
        ]
        workspace = {
            "favorites": [9],
            "history": [{"id": 9, "t": "today"}],
            "plan": {"Mon-Breakfast": 9},
            "customRecipes": [recipe],
        }

        response = self.put("/api/workspace/", {"revision": 0, "data": workspace})
        self.assertEqual(response.status_code, 200)
        saved = self.client.get("/api/workspace/").json()["data"]
        self.assertEqual(saved["customRecipes"], [recipe])
        self.assertEqual(saved["favorites"], [9])
        self.assertEqual(saved["history"][0]["id"], 9)
        self.assertEqual(saved["plan"]["Mon-Breakfast"], 9)

    def test_workspace_rejects_invalid_custom_recipe_contract(self):
        self.post(
            "/api/auth/register/",
            {
                "name": "Savorelle User",
                "username": "invalid_recipe_user",
                "email": "invalid-recipe@example.com",
                "password": "A-safe-password-123",
                "acceptedTerms": True,
            },
        )
        recipe = {
            "id": 9,
            "name": "Chickpea bowl",
            "time": 25,
            "diff": "Easy",
            "diet": "vegan",
            "kcal": 400,
            "pro": 18,
            "ing": [{"n": "chickpea", "q": 200, "u": "g"}],
            "prep": ["Rinse chickpeas."],
            "cook": ["Warm and serve."],
            "gen": 1,
        }
        response = self.put(
            "/api/workspace/",
            {"revision": 0, "data": {"customRecipes": [recipe]}},
        )
        self.assertEqual(response.status_code, 400)

        recipe["gen"] = True
        response = self.put(
            "/api/workspace/",
            {
                "revision": 0,
                "data": {
                    "plan": {"Mon-Breakfast": 99},
                    "customRecipes": [recipe],
                },
            },
        )
        self.assertEqual(response.status_code, 400)

        recipe["versions"] = [
            {
                "savedAt": "2025-01-01T12:00:00.000Z",
                "snapshot": {"name": "Incomplete snapshot"},
            }
        ]
        response = self.put(
            "/api/workspace/",
            {"revision": 0, "data": {"customRecipes": [recipe]}},
        )
        self.assertEqual(response.status_code, 400)

    def test_image_scan_rejects_non_image_upload(self):
        response = self.client.post(
            "/api/scan/",
            {
                "image": SimpleUploadedFile(
                    "scan.png",
                    b"not an image",
                    content_type="image/png",
                )
            },
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )
        self.assertEqual(response.status_code, 400)

    @override_settings(GEMINI_API_KEY="")
    def test_valid_image_without_provider_fails_instead_of_returning_guesses(self):
        archive_path = PROJECT_ROOT / "food_image_starter_dataset.zip"
        with zipfile.ZipFile(archive_path) as archive:
            filename = next(name for name in archive.namelist() if name.lower().endswith(".jpg"))
            image_bytes = archive.read(filename)
        self.client.get("/api/csrf/")
        response = self.client.post(
            "/api/scan/",
            {
                "image": SimpleUploadedFile(
                    Path(filename).name,
                    image_bytes,
                    content_type="image/jpeg",
                )
            },
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )
        self.assertEqual(response.status_code, 503)
        self.assertEqual(
            response.json()["error"],
            "AI features are unavailable. Configure GEMINI_API_KEY on the server.",
        )

    @override_settings(
        GEMINI_API_KEY="test-api-key", GEMINI_MODEL="gemini-2.5-flash"
    )
    @patch("core.ai.urlopen")
    def test_gemini_scan_returns_validated_reviewable_suggestions(
        self, mock_urlopen
    ):
        result = {
            "is_food": True,
            "dish": "Tomato and spinach curry",
            "ingredients": [
                {
                    "name": "Tomato",
                    "quantity": 180,
                    "unit": "g",
                    "confidence": 0.92,
                },
                {
                    "name": "Spinach",
                    "quantity": 60,
                    "unit": "g",
                    "confidence": 0.86,
                },
                {
                    "name": "Cheese",
                    "quantity": 20,
                    "unit": "g",
                    "confidence": 0.78,
                },
            ],
        }
        provider_response = {
            "output": [
                {
                    "type": "message",
                    "content": [
                        {"type": "output_text", "text": json.dumps(result)}
                    ],
                }
            ]
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps(provider_response).encode("utf-8")
        )

        response = self.client.post(
            "/api/scan/",
            {
                "image": self.jpeg_upload(),
                "allergies": json.dumps(["dairy"]),
                "avoid": json.dumps(["tomato"]),
            },
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["is_food"])
        self.assertEqual(response.json()["dish"], result["dish"])
        self.assertEqual(response.json()["withheld_count"], 2)
        self.assertEqual(
            [item["n"] for item in response.json()["ingredients"]],
            ["spinach"],
        )
        request = mock_urlopen.call_args.args[0]
        request_body = json.loads(request.data)
        self.assertEqual(request.get_header("X-goog-api-key"), "test-api-key")
        self.assertEqual(request_body["model"], "gemini-2.5-flash")
        self.assertEqual(request_body["response_format"]["mime_type"], "application/json")
        image_input = request_body["input"][1]
        self.assertEqual(image_input["type"], "image")
        self.assertEqual(image_input["mime_type"], "image/jpeg")
        prompt = request_body["input"][0]["text"]
        self.assertIn("cheese", prompt)
        self.assertIn("tomato", prompt)
        self.assertIn("Determine whether the image clearly contains food", prompt)

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_gemini_scan_rejects_non_food_images_with_clear_message(
        self, mock_urlopen
    ):
        result = {
            "is_food": False,
            "dish": "",
            "ingredients": [],
        }
        provider_response = {
            "output": [
                {
                    "type": "message",
                    "content": [
                        {"type": "output_text", "text": json.dumps(result)}
                    ],
                }
            ]
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps(provider_response).encode("utf-8")
        )

        response = self.client.post(
            "/api/scan/",
            {"image": self.jpeg_upload()},
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 422)
        self.assertEqual(
            response.json()["error"],
            "No food detected. Please provide a valid image of food.",
        )

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_gemini_scan_rejects_non_food_response_with_ingredients(
        self, mock_urlopen
    ):
        result = {
            "is_food": False,
            "dish": "",
            "ingredients": [
                {
                    "name": "tomato",
                    "quantity": 1,
                    "unit": "pc",
                    "confidence": 0.8,
                }
            ],
        }
        provider_response = {
            "output": [
                {
                    "type": "message",
                    "content": [
                        {"type": "output_text", "text": json.dumps(result)}
                    ],
                }
            ]
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps(provider_response).encode("utf-8")
        )

        response = self.client.post(
            "/api/scan/",
            {"image": self.jpeg_upload()},
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 502)
        self.assertEqual(
            response.json()["error"],
            "Gemini returned ingredients for an image classified as non-food.",
        )

    def test_scan_rejects_unknown_allergy_filters(self):
        response = self.client.post(
            "/api/scan/",
            {
                "image": self.jpeg_upload(),
                "allergies": json.dumps(["unknown-allergy"]),
            },
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.json()["error"], "Scan allergy settings are invalid."
        )

    @override_settings(GEMINI_API_KEY="")
    def test_scan_without_provider_never_returns_simulated_suggestions(self):
        response = self.client.post(
            "/api/scan/",
            {
                "image": self.jpeg_upload(),
                "allergies": json.dumps(["egg"]),
            },
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 503)
        self.assertNotIn("ingredients", response.json())

    def test_egg_allergy_does_not_block_eggplant(self):
        result = {
            "ingredients": [
                {"n": "eggplant", "q": 1, "u": "pc", "confidence": 0.9},
                {"n": "egg", "q": 1, "u": "pc", "confidence": 0.9},
            ],
        }

        filtered = _apply_allergy_filters(result, ["egg"], [])

        self.assertEqual(
            [item["n"] for item in filtered["ingredients"]], ["eggplant"]
        )
        self.assertEqual(filtered["withheld_count"], 1)

        custom_avoid = _apply_allergy_filters(result, [], ["egg"])

        self.assertEqual(
            [item["n"] for item in custom_avoid["ingredients"]], ["eggplant"]
        )
        self.assertEqual(custom_avoid["withheld_count"], 1)

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen", side_effect=URLError("offline"))
    def test_gemini_scan_reports_provider_failure_without_simulated_fallback(
        self, _mock_urlopen
    ):
        response = self.client.post(
            "/api/scan/",
            {"image": self.jpeg_upload()},
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 502)
        self.assertEqual(
            response.json()["error"],
            "Gemini is temporarily unavailable. Check the server connection and try again.",
        )

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_gemini_bad_request_includes_provider_error_detail(self, mock_urlopen):
        error_body = json.dumps(
            {"error": {"message": "The requested model is unavailable."}}
        ).encode("utf-8")
        mock_urlopen.side_effect = HTTPError(
            "https://api.openai.com/v1/responses",
            400,
            "Bad Request",
            {},
            io.BytesIO(error_body),
        )

        response = self.client.post(
            "/api/scan/",
            {"image": self.jpeg_upload()},
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 502)
        self.assertEqual(
            response.json()["error"],
            "Gemini request failed (HTTP 400): The requested model is unavailable.",
        )

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_gemini_bad_request_includes_plain_text_error_detail(self, mock_urlopen):
        mock_urlopen.side_effect = HTTPError(
            "https://api.openai.com/v1/responses",
            400,
            "Bad Request",
            {},
            io.BytesIO(b"Unsupported image format."),
        )

        response = self.client.post(
            "/api/scan/",
            {"image": self.jpeg_upload()},
            HTTP_X_CSRFTOKEN=self.client.cookies["csrftoken"].value,
        )

        self.assertEqual(response.status_code, 502)
        self.assertEqual(
            response.json()["error"],
            "Gemini request failed (HTTP 400): Unsupported image format.",
        )

    def test_recipe_generation_without_provider_returns_service_error(self):
        response = self.post(
            "/api/recipes/generate/",
            {
                "ingredients": [
                    {"n": "rice", "q": 300, "u": "g"},
                    {"n": "onion", "q": 1, "u": "pc"},
                ]
            },
        )

        self.assertEqual(response.status_code, 503)
        self.assertEqual(
            response.json()["error"],
            "AI features are unavailable. Configure GEMINI_API_KEY on the server.",
        )

    @override_settings(GEMINI_API_KEY="test-api-key", GEMINI_MODEL="gemini-2.5-flash")
    @patch("core.ai.urlopen")
    def test_gemini_generates_recipe_in_workspace_format(self, mock_urlopen):
        recipe = {
            "name": "Ginger rice bowl",
            "time": 25,
            "diff": "Easy",
            "kcal": 350,
            "pro": 12,
            "ingredients": [
                {"name": "rice", "quantity": 300, "unit": "g"},
                {"name": "onion", "quantity": 1, "unit": "pc"},
            ],
            "prep": ["Rinse the rice.", "Slice the onion."],
            "cook": ["Cook rice until tender.", "Saute the onion and serve."],
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps({"output_text": json.dumps(recipe)}).encode("utf-8")
        )
        response = self.post(
            "/api/recipes/generate/",
            {
                "ingredients": [
                    {"n": "rice", "q": 300, "u": "g"},
                    {"n": "onion", "q": 1, "u": "pc"},
                ],
                "allergies": ["dairy"],
                "avoid": ["peanuts"],
                "preferences": {"diet": "Any", "time": 0, "diff": "Any"},
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["recipe"]["name"], recipe["name"])
        self.assertEqual(response.json()["recipe"]["diet"], "vegan")
        self.assertEqual(
            response.json()["recipe"]["ing"],
            [
                {"n": "rice", "q": 300.0, "u": "g"},
                {"n": "onion", "q": 1.0, "u": "pc"},
            ],
        )
        request = mock_urlopen.call_args.args[0]
        self.assertEqual(request.get_header("X-goog-api-key"), "test-api-key")
        request_body = json.loads(request.data)
        self.assertEqual(request_body["model"], "gemini-2.5-flash")
        self.assertIn("peanuts", request_body["input"][0]["text"])

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_recipe_generation_rejects_allergy_conflict(self, mock_urlopen):
        recipe = {
            "name": "Cheese rice",
            "time": 20,
            "diff": "Easy",
            "kcal": 400,
            "pro": 15,
            "ingredients": [
                {"name": "rice", "quantity": 300, "unit": "g"},
                {"name": "cheese", "quantity": 30, "unit": "g"},
            ],
            "prep": ["Rinse the rice."],
            "cook": ["Cook the rice with cheese."],
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps({"output_text": json.dumps(recipe)}).encode("utf-8")
        )
        response = self.post(
            "/api/recipes/generate/",
            {
                "ingredients": [
                    {"n": "rice", "q": 300, "u": "g"},
                    {"n": "onion", "q": 1, "u": "pc"},
                ],
                "allergies": ["dairy"],
            },
        )

        self.assertEqual(response.status_code, 502)
        self.assertIn("matching your allergy", response.json()["error"])

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_youtube_import_sends_public_video_to_gemini(self, mock_urlopen):
        recipe = {
            "name": "Quick rice bowl",
            "time": 20,
            "diff": "Easy",
            "kcal": 330,
            "pro": 10,
            "ingredients": [
                {"name": "rice", "quantity": 250, "unit": "g"},
                {"name": "onion", "quantity": 1, "unit": "pc"},
            ],
            "prep": ["Slice the onion."],
            "cook": ["Cook rice and onion until tender."],
        }
        mock_urlopen.return_value = io.BytesIO(
            json.dumps({"output_text": json.dumps(recipe)}).encode("utf-8")
        )
        response = self.post(
            "/api/youtube/import/",
            {"url": "https://youtu.be/9hE5-98ZeCg"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["recipe"]["name"], recipe["name"])
        request_body = json.loads(mock_urlopen.call_args.args[0].data)
        self.assertEqual(
            request_body["input"][1],
            {
                "type": "video",
                "uri": "https://www.youtube.com/watch?v=9hE5-98ZeCg",
            },
        )

    @override_settings(GEMINI_API_KEY="test-api-key")
    @patch("core.ai.urlopen")
    def test_youtube_import_rejects_non_youtube_links(self, mock_urlopen):
        response = self.post(
            "/api/youtube/import/",
            {"url": "https://example.com/watch?v=9hE5-98ZeCg"},
        )

        self.assertEqual(response.status_code, 400)
        mock_urlopen.assert_not_called()

    def test_recipe_examples_are_consistent_between_csv_and_json(self):
        with (PROJECT_ROOT / "recipes.csv").open(encoding="utf-8", newline="") as csv_file:
            csv_recipes = list(csv.DictReader(csv_file))
        json_recipes = json.loads((PROJECT_ROOT / "recipes.json").read_text(encoding="utf-8"))

        self.assertEqual(len(csv_recipes), 50)
        self.assertEqual(len(json_recipes), 50)
        self.assertEqual(
            [recipe["recipe_id"] for recipe in csv_recipes],
            [recipe["recipe_id"] for recipe in json_recipes],
        )
        for recipe in json_recipes:
            self.assertTrue(recipe["recipe_name"])
            self.assertTrue(recipe["ingredients"])
            self.assertTrue(recipe["instructions"])
            self.assertGreaterEqual(recipe["prep_time_min"], 0)
            self.assertGreaterEqual(recipe["cook_time_min"], 0)

    def test_provided_image_archives_contain_decodable_jpegs(self):
        archives = (
            ("food_image_starter_dataset.zip", 20),
            ("world_food_diverse_starter_dataset.zip", 68),
        )
        for archive_name, expected_count in archives:
            with self.subTest(archive=archive_name):
                with zipfile.ZipFile(PROJECT_ROOT / archive_name) as archive:
                    images = [
                        name
                        for name in archive.namelist()
                        if name.lower().endswith((".jpg", ".jpeg"))
                    ]
                    self.assertEqual(len(images), expected_count)
                    for image_name in images:
                        with Image.open(io.BytesIO(archive.read(image_name))) as image:
                            self.assertEqual(image.format, "JPEG")
                            image.verify()
