from django.urls import path

from . import views


urlpatterns = [
    path("csrf/", views.csrf_token, name="csrf"),
    path("demo-recipes/", views.demo_recipes, name="demo-recipes"),
    path("auth/me/", views.current_user, name="current-user"),
    path("auth/register/", views.register, name="register"),
    path("auth/login/", views.login_view, name="login"),
    path("auth/logout/", views.logout_view, name="logout"),
    path("workspace/", views.workspace, name="workspace"),
    path("scan/", views.scan_image, name="scan-image"),
    path("recipes/generate/", views.generate_recipe, name="generate-recipe"),
    path("youtube/import/", views.import_youtube_recipe, name="import-youtube-recipe"),
]
