import base64
import json
import math
import re
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, urlopen

from django.conf import settings


GEMINI_INTERACTIONS_URL = (
    "https://generativelanguage.googleapis.com/v1beta/interactions"
)
ALLOWED_UNITS = {"g", "ml", "pc"}
ALLERGEN_INGREDIENTS = {
    "gluten": ("pasta", "bread", "noodles", "flour", "roti", "wheat"),
    "dairy": ("yogurt", "paneer", "milk", "butter", "cheese", "ghee", "cream"),
    "egg": ("egg",),
    "peanuts": ("peanut",),
    "tree nuts": ("almond", "cashew", "walnut", "pistachio"),
    "soy": ("soy", "tofu"),
    "fish": ("fish",),
    "shellfish": ("prawn", "shrimp", "crab"),
    "sesame": ("sesame",),
    "mustard": ("mustard",),
    "legumes": ("chickpea", "lentil", "peas", "bean"),
}
ANIMAL_PRODUCTS = (
    "chicken",
    "fish",
    "prawn",
    "shrimp",
    "mutton",
    "beef",
    "pork",
    "lamb",
    "meat",
    "bacon",
    "ham",
    "crab",
    "lobster",
    "turkey",
)


class AIConfigurationError(Exception):
    pass


class AIProviderError(Exception):
    pass


class NonFoodImageError(Exception):
    pass


def _extract_output_text(response):
    if not isinstance(response, dict):
        raise AIProviderError("Gemini returned an invalid response.")
    text = response.get("output_text")
    if isinstance(text, str) and text.strip():
        return text
    outputs = response.get("output", [])
    if not isinstance(outputs, list):
        raise AIProviderError("Gemini returned an invalid response.")
    for output in outputs:
        if not isinstance(output, dict):
            continue
        contents = output.get("content", [])
        if not isinstance(contents, list):
            continue
        for content in contents:
            if (
                isinstance(content, dict)
                and content.get("type") in {"text", "output_text"}
                and isinstance(content.get("text"), str)
            ):
                return content["text"]
    raise AIProviderError("Gemini returned no usable structured data.")


def _gemini_error_detail(error):
    try:
        body = error.read(4096).decode("utf-8", errors="replace").strip()
    except OSError:
        return ""
    if not body:
        return ""
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        return "" if body.startswith("<") else body[:300]
    if not isinstance(parsed, dict):
        return ""
    provider_error = parsed.get("error")
    detail = provider_error.get("message") if isinstance(provider_error, dict) else None
    return detail.strip()[:300] if isinstance(detail, str) else ""


def _request_gemini(input_parts, schema, timeout=60):
    if not settings.GEMINI_API_KEY:
        raise AIConfigurationError(
            "AI features are unavailable. Configure GEMINI_API_KEY on the server."
        )
    request_body = {
        "model": settings.GEMINI_MODEL,
        "input": input_parts,
        "response_format": {
            "type": "text",
            "mime_type": "application/json",
            "schema": schema,
        },
    }
    request = Request(
        GEMINI_INTERACTIONS_URL,
        data=json.dumps(request_body).encode("utf-8"),
        headers={
            "x-goog-api-key": settings.GEMINI_API_KEY,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            body = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        if exc.code in (401, 403):
            message = "Gemini rejected the configured API credentials."
        elif exc.code == 429:
            message = "Gemini rate limit reached; try again later."
        else:
            detail = _gemini_error_detail(exc)
            message = (
                f"Gemini request failed (HTTP {exc.code}): {detail}"
                if detail
                else f"Gemini request failed (HTTP {exc.code})."
            )
        raise AIProviderError(message) from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise AIProviderError(
            "Gemini is temporarily unavailable. Check the server connection and try again."
        ) from exc
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise AIProviderError("Gemini returned an invalid response.") from exc

    try:
        return json.loads(_extract_output_text(body))
    except json.JSONDecodeError as exc:
        raise AIProviderError("Gemini returned invalid structured data.") from exc


def _ingredient_is_blocked(name, allergies, avoid):
    normalized_name = name.strip().lower()
    terms = [
        term
        for allergy in allergies
        for term in ALLERGEN_INGREDIENTS[allergy]
    ]
    terms.extend(term.strip().lower() for term in avoid if term.strip())
    return any(
        re.search(
            rf"(?<![a-z0-9]){re.escape(term)}(?:s|es)?(?![a-z0-9])",
            normalized_name,
        )
        for term in terms
    )


def _apply_allergy_filters(result, allergies, avoid):
    ingredients = [
        ingredient
        for ingredient in result["ingredients"]
        if not _ingredient_is_blocked(ingredient["n"], allergies, avoid)
    ]
    return {
        **result,
        "withheld_count": result.get("withheld_count", 0)
        + len(result["ingredients"])
        - len(ingredients),
        "ingredients": ingredients,
    }


def _food_schema():
    return {
        "type": "object",
        "properties": {
            "is_food": {"type": "boolean"},
            "dish": {"type": "string"},
            "ingredients": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "quantity": {"type": "number"},
                        "unit": {"type": "string", "enum": ["g", "ml", "pc"]},
                        "confidence": {"type": "number"},
                    },
                    "required": ["name", "quantity", "unit", "confidence"],
                    "additionalProperties": False,
                },
            },
        },
        "required": ["is_food", "dish", "ingredients"],
        "additionalProperties": False,
    }


def _validate_food_analysis(analysis):
    if not isinstance(analysis, dict):
        raise AIProviderError("Gemini returned invalid structured image data.")
    is_food = analysis.get("is_food")
    dish = analysis.get("dish")
    ingredients = analysis.get("ingredients")
    if (
        not isinstance(is_food, bool)
        or not isinstance(dish, str)
        or len(dish.strip()) > 120
        or not isinstance(ingredients, list)
        or len(ingredients) > 30
    ):
        raise AIProviderError("Gemini returned invalid structured image data.")
    if not is_food:
        if ingredients:
            raise AIProviderError(
                "Gemini returned ingredients for an image classified as non-food."
            )
        return {"is_food": False, "dish": "", "withheld_count": 0, "ingredients": []}

    cleaned = []
    for ingredient in ingredients:
        if not isinstance(ingredient, dict):
            raise AIProviderError("Gemini returned an invalid ingredient.")
        name = ingredient.get("name")
        quantity = ingredient.get("quantity")
        unit = ingredient.get("unit")
        confidence = ingredient.get("confidence")
        if (
            not isinstance(name, str)
            or not name.strip()
            or len(name.strip()) > 100
            or isinstance(quantity, bool)
            or not isinstance(quantity, (int, float))
            or not math.isfinite(quantity)
            or not 0 < quantity <= 100000
            or not isinstance(unit, str)
            or unit not in ALLOWED_UNITS
            or isinstance(confidence, bool)
            or not isinstance(confidence, (int, float))
            or not math.isfinite(confidence)
            or not 0 <= confidence <= 1
        ):
            raise AIProviderError("Gemini returned an invalid ingredient.")
        cleaned.append(
            {
                "n": name.strip().lower(),
                "q": round(quantity, 1),
                "u": unit,
                "confidence": round(confidence, 3),
            }
        )
    return {
        "is_food": True,
        "dish": dish.strip(),
        "withheld_count": 0,
        "ingredients": sorted(
            cleaned, key=lambda ingredient: ingredient["confidence"], reverse=True
        ),
    }


def detect_ingredients(image_bytes, image_mime_type, allergies=(), avoid=()):
    blocked = sorted(
        {
            term
            for allergy in allergies
            for term in ALLERGEN_INGREDIENTS[allergy]
        }
        | {term.strip().lower() for term in avoid if term.strip()}
    )
    prompt = (
        "Determine whether the image clearly contains food. For non-food, return "
        "is_food=false, an empty dish, and no ingredients. For food, identify the "
        "visible dish and estimate up to 30 plausible visible ingredients. Do not "
        "claim hidden allergens, exact quantities, or unseen seasonings as facts. "
        "Use grams for solids, milliliters for liquids, and pieces for countable "
        "items. Mark uncertain visual inferences with lower confidence. Do not "
        "include these allergy or avoid terms: "
        f"{', '.join(blocked) or 'none'}. Quantities are estimates for user review."
    )
    analysis = _request_gemini(
        [
            {"type": "text", "text": prompt},
            {
                "type": "image",
                "data": base64.b64encode(image_bytes).decode("ascii"),
                "mime_type": image_mime_type,
            },
        ],
        _food_schema(),
    )
    result = _validate_food_analysis(analysis)
    if not result["is_food"]:
        raise NonFoodImageError(
            "No food detected. Please provide a valid image of food."
        )
    return _apply_allergy_filters(result, allergies, avoid)


def _recipe_schema():
    return {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "time": {"type": "integer"},
            "diff": {"type": "string", "enum": ["Easy", "Medium", "Hard"]},
            "kcal": {"type": "integer"},
            "pro": {"type": "integer"},
            "ingredients": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "quantity": {"type": "number"},
                        "unit": {"type": "string", "enum": ["g", "ml", "pc"]},
                    },
                    "required": ["name", "quantity", "unit"],
                    "additionalProperties": False,
                },
            },
            "prep": {"type": "array", "items": {"type": "string"}},
            "cook": {"type": "array", "items": {"type": "string"}},
        },
        "required": [
            "name", "time", "diff", "kcal", "pro", "ingredients", "prep", "cook",
        ],
        "additionalProperties": False,
    }


def _diet_category(ingredients):
    names = [ingredient["n"] for ingredient in ingredients]
    if any(_contains_term(name, ANIMAL_PRODUCTS) for name in names):
        return "nonveg"
    if any(_contains_term(name, ("egg",)) for name in names):
        return "egg"
    if any(
        _contains_term(
            name,
            (
                "paneer", "yogurt", "milk", "butter", "cheese", "ghee",
                "cream", "honey", "gelatin",
            ),
        )
        for name in names
    ):
        return "veg"
    return "vegan"


def _contains_term(name, terms):
    return any(
        re.search(
            rf"(?<![a-z0-9]){re.escape(term)}(?:s|es)?(?![a-z0-9])",
            name.lower(),
        )
        for term in terms
    )


def _validate_recipe(recipe, allergies, avoid, preferences):
    if not isinstance(recipe, dict):
        raise AIProviderError("Gemini returned an invalid recipe.")
    name = recipe.get("name")
    diff = recipe.get("diff")
    time = recipe.get("time")
    kcal = recipe.get("kcal")
    protein = recipe.get("pro")
    ingredients = recipe.get("ingredients")
    prep = recipe.get("prep")
    cook = recipe.get("cook")
    if (
        not isinstance(name, str)
        or not name.strip()
        or len(name.strip()) > 120
        or         not isinstance(diff, str)
        or diff not in {"Easy", "Medium", "Hard"}
        or isinstance(time, bool)
        or not isinstance(time, int)
        or not 1 <= time <= 360
        or isinstance(kcal, bool)
        or not isinstance(kcal, int)
        or not 0 <= kcal <= 5000
        or isinstance(protein, bool)
        or not isinstance(protein, int)
        or not 0 <= protein <= 300
        or not isinstance(ingredients, list)
        or not 2 <= len(ingredients) <= 50
        or not isinstance(prep, list)
        or not 1 <= len(prep) <= 20
        or not isinstance(cook, list)
        or not 1 <= len(cook) <= 30
    ):
        raise AIProviderError("Gemini returned an invalid recipe.")

    cleaned = []
    for ingredient in ingredients:
        if not isinstance(ingredient, dict):
            raise AIProviderError("Gemini returned an invalid recipe ingredient.")
        ingredient_name = ingredient.get("name")
        quantity = ingredient.get("quantity")
        unit = ingredient.get("unit")
        if (
            not isinstance(ingredient_name, str)
            or not ingredient_name.strip()
            or len(ingredient_name.strip()) > 100
            or isinstance(quantity, bool)
            or not isinstance(quantity, (int, float))
            or not math.isfinite(quantity)
            or not 0 < quantity <= 100000
            or not isinstance(unit, str)
            or unit not in ALLOWED_UNITS
        ):
            raise AIProviderError("Gemini returned an invalid recipe ingredient.")
        normalized = ingredient_name.strip().lower()
        if _ingredient_is_blocked(normalized, allergies, avoid):
            raise AIProviderError(
                "Gemini included an ingredient matching your allergy or avoid settings. "
                "The recipe was not added."
            )
        cleaned.append(
            {"n": normalized, "q": round(quantity, 1), "u": unit}
        )

    for step_list in (prep, cook):
        if any(
            not isinstance(step, str) or not step.strip() or len(step.strip()) > 500
            for step in step_list
        ):
            raise AIProviderError("Gemini returned an invalid recipe step.")
    diet = _diet_category(cleaned)
    if preferences["diet"] == "Vegan" and diet != "vegan":
        raise AIProviderError("Gemini returned a recipe that does not meet your vegan preference.")
    if preferences["diet"] == "Vegetarian" and diet == "nonveg":
        raise AIProviderError(
            "Gemini returned a recipe that does not meet your vegetarian preference."
        )
    if preferences["diet"] == "Non-vegetarian" and diet not in {"egg", "nonveg"}:
        raise AIProviderError(
            "Gemini returned a recipe that does not meet your non-vegetarian preference."
        )
    if preferences["diet"] == "High protein" and protein < 20:
        raise AIProviderError(
            "Gemini returned a recipe below your high-protein preference."
        )
    if preferences["time"] and time > preferences["time"]:
        raise AIProviderError("Gemini returned a recipe over your time limit.")
    if preferences["diff"] != "Any" and diff != preferences["diff"]:
        raise AIProviderError("Gemini returned a recipe outside your difficulty preference.")
    return {
        "name": name.strip(),
        "time": time,
        "diff": diff,
        "diet": diet,
        "kcal": kcal,
        "pro": protein,
        "ing": cleaned,
        "prep": [step.strip() for step in prep],
        "cook": [step.strip() for step in cook],
    }


def _recipe_prompt(ingredients, allergies, avoid, preferences, source):
    context = {
        "available_ingredients": ingredients,
        "allergies": list(allergies),
        "foods_to_avoid": list(avoid),
        "preferences": preferences,
        "source": source,
    }
    return (
        "Create one practical recipe using the available ingredients where "
        "possible. State every ingredient and quantity needed, including any "
        "additional ingredients, because the app uses this list for shopping. "
        "Never include an allergy or avoided ingredient. Respect all dietary, "
        "time, and difficulty preferences. Use only g, ml, or pc units and "
        "metric quantities. Provide concise preparation and cooking steps. "
        "Estimate kcal and protein per serving; they are not laboratory-verified. "
        "Do not claim hidden ingredients from a video. If the source does not "
        "show or describe a coherent recipe, return the best recipe supported "
        "by its visible or spoken content.\n"
        f"Recipe request: {json.dumps(context, ensure_ascii=True)}"
    )


def generate_recipe(ingredients, allergies, avoid, preferences):
    prompt = _recipe_prompt(
        ingredients, allergies, avoid, preferences, "user ingredients"
    )
    result = _request_gemini(
        [{"type": "text", "text": prompt}], _recipe_schema()
    )
    return _validate_recipe(result, allergies, avoid, preferences)


def _youtube_video_uri(url):
    try:
        parsed = urlsplit(url.strip())
        port = parsed.port
    except ValueError:
        raise ValueError("Enter a valid public YouTube video link.") from None
    host = (parsed.hostname or "").lower()
    if (
        parsed.scheme not in {"http", "https"}
        or parsed.username is not None
        or parsed.password is not None
        or port not in (None, 80, 443)
        or host not in {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"}
    ):
        raise ValueError("Enter a valid public YouTube video link.")
    if host == "youtu.be":
        match = re.fullmatch(r"/([A-Za-z0-9_-]{11})/?", parsed.path)
        video_id = match.group(1) if match else ""
    elif parsed.path == "/watch":
        video_id = parse_qs(parsed.query).get("v", [""])[0]
    else:
        match = re.fullmatch(r"/(?:shorts|live|embed)/([A-Za-z0-9_-]{11})/?", parsed.path)
        video_id = match.group(1) if match else ""
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", video_id):
        raise ValueError("Enter a valid public YouTube video link.")
    return f"https://www.youtube.com/watch?v={video_id}"


def import_youtube_recipe(url, allergies, avoid, preferences):
    video_uri = _youtube_video_uri(url)
    prompt = _recipe_prompt(
        [],
        allergies,
        avoid,
        preferences,
        f"public YouTube cooking video {video_uri}",
    )
    prompt += (
        "\nExtract a recipe actually demonstrated or described in this video. "
        "Use the video's spoken instructions and visible food. Do not invent "
        "quantities that are unsupported; mark reasonable estimates clearly in "
        "the recipe steps."
    )
    result = _request_gemini(
        [
            {"type": "text", "text": prompt},
            {"type": "video", "uri": video_uri},
        ],
        _recipe_schema(),
        timeout=120,
    )
    return _validate_recipe(result, allergies, avoid, preferences)
