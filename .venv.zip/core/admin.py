from django.contrib import admin

from .models import UserWorkspace


@admin.register(UserWorkspace)
class UserWorkspaceAdmin(admin.ModelAdmin):
    list_display = ("user", "revision", "updated_at")
    search_fields = ("user__username", "user__email")
    readonly_fields = ("revision", "updated_at")
