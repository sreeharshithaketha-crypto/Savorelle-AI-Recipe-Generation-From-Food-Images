import hashlib
import json
import re
from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db import IntegrityError
from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST
from PIL import Image, UnidentifiedImageError

from .ai import (
    AIConfigurationError,
    AIProviderError,
    NonFoodImageError,
    _diet_category,
    _ingredient_is_blocked,
    detect_ingredients,
    generate_recipe as generate_ai_recipe,
    import_youtube_recipe as import_ai_youtube_recipe,
)
from .models import UserWorkspace


MAX_JSON_BYTES = 1_000_000
MAX_IMAGE_BYTES = 8_000_000
IMAGE_FORMATS = {"JPEG", "PNG", "WEBP"}
BUILTIN_RECIPE_IDS = set(range(1, 9))
SCAN_ALLERGIES = {
    "gluten",
    "dairy",
    "egg",
    "peanuts",
    "tree nuts",
    "soy",
    "fish",
    "shellfish",
    "sesame",
    "mustard",
    "legumes",
}


def _json_body(request, max_bytes=MAX_JSON_BYTES):
    if len(request.body) > max_bytes:
        raise ValueError("The request is too large.")
    try:
        value = json.loads(request.body)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ValueError("Send valid JSON.") from exc
    if not isinstance(value, dict):
        raise ValueError("Send a JSON object.")
    return value


def _error(message, status=400):
    return JsonResponse({"error": message}, status=status)


def _scan_filter_values(request):
    try:
        allergies = json.loads(request.POST.get("allergies", "[]"))
        avoid = json.loads(request.POST.get("avoid", "[]"))
    except json.JSONDecodeError as exc:
        raise ValueError("Scan allergy settings are invalid.") from exc
    if (
        not isinstance(allergies, list)
        or len(allergies) > len(SCAN_ALLERGIES)
        or any(
            not isinstance(item, str) or item not in SCAN_ALLERGIES
            for item in allergies
        )
    ):
        raise ValueError("Scan allergy settings are invalid.")
    if (
        not isinstance(avoid, list)
        or len(avoid) > 100
        or any(
            not isinstance(item, str) or not item.strip() or len(item) > 100
            for item in avoid
        )
    ):
        raise ValueError("Scan foods-to-avoid settings are invalid.")
    return list(dict.fromkeys(allergies)), [
        item.strip().lower() for item in avoid
    ]


@ensure_csrf_cookie
def home(request):
    html = (settings.BASE_DIR / "index.html").read_text(encoding="utf-8")
    return HttpResponse(html)


@require_GET
def csrf_token(request):
    return JsonResponse({"csrfToken": get_token(request)})


@require_GET
def demo_recipes(request):
    recipes = json.loads(
        (settings.BASE_DIR / "recipes.json").read_text(encoding="utf-8")
    )
    return JsonResponse(recipes, safe=False)


@require_GET
def current_user(request):
    if not request.user.is_authenticated:
        return JsonResponse({"authenticated": False})
    return JsonResponse(
        {
            "authenticated": True,
            "user": {
                "username": request.user.get_username(),
                "name": request.user.first_name,
            },
        }
    )


@require_POST
def register(request):
    try:
        body = _json_body(request)
    except ValueError as exc:
        return _error(str(exc))

    name = str(body.get("name", "")).strip()
    username = str(body.get("username", "")).strip()
    email = str(body.get("email", "")).strip().lower()
    password = body.get("password")
    if not name or len(name) > 150:
        return _error("Enter a name no longer than 150 characters.")
    if not re.fullmatch(r"[A-Za-z0-9_]{3,20}", username):
        return _error("Username must be 3 to 20 letters, numbers or underscores.")
    if not isinstance(password, str):
        return _error("Enter a password.")
    if body.get("acceptedTerms") is not True:
        return _error("Accept the terms and privacy policy to create an account.")
    try:
        validate_email(email)
        validate_password(password)
    except ValidationError as exc:
        return _error(" ".join(exc.messages))
    if get_user_model().objects.filter(email__iexact=email).exists():
        return _error("An account with this email already exists.")
    if get_user_model().objects.filter(username__iexact=username).exists():
        return _error("That username is already taken.")

    try:
        user = get_user_model().objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=name,
        )
    except IntegrityError:
        return _error("That username or email is already in use.")
    login(request, user)
    return JsonResponse(
        {
            "authenticated": True,
            "user": {"username": user.get_username(), "name": user.first_name},
        },
        status=201,
    )


@require_POST
def login_view(request):
    try:
        body = _json_body(request)
    except ValueError as exc:
        return _error(str(exc))

    identifier = str(body.get("identifier", "")).strip()
    password = body.get("password")
    if not identifier or not isinstance(password, str):
        return _error("Enter your email or username and password.")

    user_model = get_user_model()
    user = user_model.objects.filter(email__iexact=identifier).first()
    if user is None:
        user = user_model.objects.filter(username__iexact=identifier).first()
    username = user.get_username() if user else identifier
    user = authenticate(request, username=username, password=password)
    if user is None:
        return _error("The email, username or password is incorrect.", status=400)
    login(request, user)
    return JsonResponse(
        {
            "authenticated": True,
            "user": {"username": user.get_username(), "name": user.first_name},
        }
    )


@require_POST
def logout_view(request):
    logout(request)
    return JsonResponse({"authenticated": False})


def _bounded_text(value, label, limit=160, allow_empty=False):
    if not isinstance(value, str):
        raise ValueError(f"{label} must be text.")
    value = value.strip()
    if (not value and not allow_empty) or len(value) > limit:
        raise ValueError(f"{label} must be 1 to {limit} characters.")
    return value


def _bounded_number(value, label, minimum=0, maximum=100000):
    if isinstance(value, bool):
        raise ValueError(f"{label} must be a number.")
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{label} must be a number.") from None
    if not number.is_finite() or number < minimum or number > maximum:
        raise ValueError(f"{label} is outside the allowed range.")
    return float(number)


def _clean_recipe_content(recipe):
    if not isinstance(recipe, dict):
        raise ValueError("Recipe versions must contain recipe objects.")
    ingredients = recipe.get("ing", [])
    if not isinstance(ingredients, list) or len(ingredients) > 100:
        raise ValueError("A recipe can contain up to 100 ingredients.")
    cleaned_ingredients = []
    for ingredient in ingredients:
        if not isinstance(ingredient, dict):
            raise ValueError("Recipe ingredients must be objects.")
        cleaned_ingredients.append(
            {
                "n": _bounded_text(
                    ingredient.get("n"), "Ingredient name", 100
                ).lower(),
                "q": _bounded_number(
                    ingredient.get("q"), "Ingredient quantity", 0, 100000
                ),
                "u": _bounded_text(ingredient.get("u"), "Ingredient unit", 10),
            }
        )

    steps = {}
    for key in ("prep", "cook"):
        values = recipe.get(key, [])
        if not isinstance(values, list) or len(values) > 50:
            raise ValueError("Recipe instructions must be lists of at most 50 steps.")
        steps[key] = [
            _bounded_text(value, "Recipe step", 1000) for value in values
        ]

    diet = recipe.get("diet", "")
    if not isinstance(diet, str):
        raise ValueError("Recipe diet labels are invalid.")
    generated = recipe.get("gen", False)
    if not isinstance(generated, bool):
        raise ValueError("Recipe generation status is invalid.")
    return {
        "name": _bounded_text(recipe.get("name"), "Recipe name", 120),
        "time": int(_bounded_number(recipe.get("time", 0), "Recipe time", 1, 600)),
        "diff": _bounded_text(recipe.get("diff", "Easy"), "Difficulty", 40),
        "diet": _bounded_text(diet, "Diet", 40, True),
        "kcal": int(_bounded_number(recipe.get("kcal", 0), "Calories", 0, 10000)),
        "pro": int(_bounded_number(recipe.get("pro", 0), "Protein", 0, 1000)),
        "ing": cleaned_ingredients,
        "prep": steps["prep"],
        "cook": steps["cook"],
        "src": _bounded_text(recipe.get("src", ""), "Recipe source", 500, True),
        "gen": generated,
    }


def _validate_workspace(data):
    allowed = {
        "inventory",
        "favorites",
        "history",
        "plan",
        "bought",
        "allergies",
        "avoid",
        "preferences",
        "calories",
        "notes",
        "customRecipes",
    }
    if set(data) - allowed:
        raise ValueError("The workspace contains unknown fields.")
    result = {}
    inventory = data.get("inventory", [])
    if not isinstance(inventory, list) or len(inventory) > 500:
        raise ValueError("Inventory must contain at most 500 items.")
    result["inventory"] = [
        {
            "n": _bounded_text(item.get("n"), "Ingredient name", 100).lower(),
            "q": _bounded_number(item.get("q"), "Quantity", 0, 1000000),
            "u": _bounded_text(item.get("u"), "Unit", 10),
        }
        for item in inventory
        if isinstance(item, dict)
    ]
    if len(result["inventory"]) != len(inventory):
        raise ValueError("Every inventory item must be an object.")

    for key in ("favorites",):
        values = data.get(key, [])
        if not isinstance(values, list) or len(values) > 500:
            raise ValueError(f"{key} must be a list of at most 500 recipe IDs.")
        if any(
            not isinstance(value, int) or isinstance(value, bool) or value < 1
            for value in values
        ):
            raise ValueError(f"{key} must contain recipe IDs.")
        result[key] = list(dict.fromkeys(values))

    history = data.get("history", [])
    if not isinstance(history, list) or len(history) > 30:
        raise ValueError("History must contain at most 30 entries.")
    result["history"] = []
    for item in history:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("id"), int)
            or isinstance(item.get("id"), bool)
            or item["id"] < 1
        ):
            raise ValueError("History entries must have a recipe ID.")
        result["history"].append(
            {
                "id": item["id"],
                "t": _bounded_text(item.get("t", ""), "History time", 80, True),
            }
        )

    plan = data.get("plan", {})
    if not isinstance(plan, dict) or len(plan) > 56:
        raise ValueError("The meal plan has too many entries.")
    result["plan"] = {}
    for key, value in plan.items():
        if not isinstance(key, str) or len(key) > 32:
            raise ValueError("Meal-plan keys must be short text.")
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise ValueError("Meal-plan entries must contain recipe IDs.")
        result["plan"][key] = value

    for key in ("bought", "allergies", "avoid"):
        values = data.get(key, [])
        if not isinstance(values, list) or len(values) > 500:
            raise ValueError(f"{key} must be a list of at most 500 values.")
        result[key] = [_bounded_text(value, key, 100) for value in values]

    preferences = data.get("preferences", {})
    if not isinstance(preferences, dict) or len(preferences) > 20:
        raise ValueError("Preferences must be an object.")
    diet = preferences.get("diet", "Any")
    difficulty = preferences.get("diff", "Any")
    result["preferences"] = {
        "diet": _bounded_text(diet, "Diet preference", 40),
        "time": int(_bounded_number(preferences.get("time", 0), "Time limit", 0, 600)),
        "diff": _bounded_text(difficulty, "Difficulty preference", 40),
    }

    calories = data.get("calories", {"t": 2000, "strict": True})
    if not isinstance(calories, dict) or not isinstance(calories.get("strict", True), bool):
        raise ValueError("Calorie settings are invalid.")
    result["calories"] = {
        "t": _bounded_number(calories.get("t", 2000), "Calorie target", 500, 10000),
        "strict": calories.get("strict", True),
    }

    notes = data.get("notes", {})
    if not isinstance(notes, dict) or len(notes) > 500:
        raise ValueError("Recipe notes must be an object.")
    result["notes"] = {}
    for key, value in notes.items():
        if not isinstance(key, str) or not isinstance(value, str) or len(value) > 5000:
            raise ValueError("Recipe notes are invalid.")
        result["notes"][key] = value

    recipes = data.get("customRecipes", [])
    if not isinstance(recipes, list) or len(recipes) > 100:
        raise ValueError("You can save up to 100 custom recipes.")
    result["customRecipes"] = []
    recipe_ids = set(BUILTIN_RECIPE_IDS)
    for recipe in recipes:
        if not isinstance(recipe, dict):
            raise ValueError("Every custom recipe must be an object.")
        recipe_id = recipe.get("id")
        if not isinstance(recipe_id, int) or isinstance(recipe_id, bool) or recipe_id < 9:
            raise ValueError("Custom recipe IDs must be unique positive integers.")
        if recipe_id in recipe_ids:
            raise ValueError("Custom recipe IDs must be unique positive integers.")
        recipe_ids.add(recipe_id)
        content = _clean_recipe_content(recipe)
        versions = recipe.get("versions", [])
        if not isinstance(versions, list) or len(versions) > 10:
            raise ValueError("A recipe can keep up to 10 previous versions.")
        cleaned_versions = []
        for version in versions:
            if not isinstance(version, dict):
                raise ValueError("Recipe versions must be objects.")
            cleaned_versions.append(
                {
                    "savedAt": _bounded_text(
                        version.get("savedAt"), "Version date", 40
                    ),
                    "snapshot": _clean_recipe_content(version.get("snapshot")),
                }
            )
        result["customRecipes"].append(
            {"id": recipe_id, **content, "versions": cleaned_versions}
        )
    for key in ("favorites",):
        if any(recipe_id not in recipe_ids for recipe_id in result[key]):
            raise ValueError(f"{key} contains an unknown recipe ID.")
    if any(item["id"] not in recipe_ids for item in result["history"]):
        raise ValueError("History contains an unknown recipe ID.")
    if any(recipe_id not in recipe_ids for recipe_id in result["plan"].values()):
        raise ValueError("The meal plan contains an unknown recipe ID.")
    return result


def _login_required_json(request):
    if not request.user.is_authenticated:
        return _error("Sign in to sync your workspace.", status=401)
    return None


def workspace(request):
    unauthorized = _login_required_json(request)
    if unauthorized:
        return unauthorized
    workspace, _ = UserWorkspace.objects.get_or_create(user=request.user)
    if request.method == "GET":
        return JsonResponse({"revision": workspace.revision, "data": workspace.data})
    if request.method != "PUT":
        return _error("Use GET or PUT for workspace sync.", status=405)

    try:
        body = _json_body(request)
        revision = body.get("revision")
        if not isinstance(revision, int) or isinstance(revision, bool) or revision < 0:
            raise ValueError("A valid workspace revision is required.")
        cleaned = _validate_workspace(body.get("data", {}))
    except ValueError as exc:
        return _error(str(exc))

    updated = UserWorkspace.objects.filter(
        pk=workspace.pk,
        revision=revision,
    ).update(data=cleaned, revision=revision + 1, updated_at=timezone.now())
    if not updated:
        latest = UserWorkspace.objects.get(pk=workspace.pk)
        return JsonResponse(
            {
                "error": "This workspace changed on another device.",
                "revision": latest.revision,
                "data": latest.data,
            },
            status=409,
        )
    return JsonResponse({"revision": revision + 1})


@require_POST
def scan_image(request):
    image_file = request.FILES.get("image")
    if image_file is None:
        return _error("Choose an image to scan.")
    try:
        allergies, avoid = _scan_filter_values(request)
    except ValueError as exc:
        return _error(str(exc))
    if image_file.size > MAX_IMAGE_BYTES:
        return _error("Images must be 8 MB or smaller.")
    try:
        with Image.open(image_file) as image:
            if image.format not in IMAGE_FORMATS:
                return _error("Use a JPEG, PNG or WebP image.")
            image_mime_type = {
                "JPEG": "image/jpeg",
                "PNG": "image/png",
                "WEBP": "image/webp",
            }[image.format]
            if image.width > 6000 or image.height > 6000:
                return _error("Image dimensions must be 6000 pixels or smaller.")
            image.verify()
    except (UnidentifiedImageError, OSError):
        return _error("The selected file is not a valid image.")

    image_file.seek(0)
    payload = image_file.read()
    try:
        result = detect_ingredients(
            payload, image_mime_type, allergies, avoid
        )
    except NonFoodImageError as exc:
        return _error(str(exc), status=422)
    except AIConfigurationError as exc:
        return _error(str(exc), status=503)
    except AIProviderError as exc:
        return _error(str(exc), status=502)
    return JsonResponse(result)


def _recipe_filters(body):
    allergies = body.get("allergies", [])
    avoid = body.get("avoid", [])
    preferences = body.get("preferences", {})
    if (
        not isinstance(allergies, list)
        or len(allergies) > len(SCAN_ALLERGIES)
        or any(not isinstance(item, str) or item not in SCAN_ALLERGIES for item in allergies)
    ):
        raise ValueError("Recipe allergy settings are invalid.")
    if (
        not isinstance(avoid, list)
        or len(avoid) > 100
        or any(not isinstance(item, str) or not item.strip() or len(item) > 100 for item in avoid)
    ):
        raise ValueError("Recipe foods-to-avoid settings are invalid.")
    if not isinstance(preferences, dict):
        raise ValueError("Recipe preferences are invalid.")
    diet = preferences.get("diet", "Any")
    difficulty = preferences.get("diff", "Any")
    time_limit = preferences.get("time", 0)
    if not isinstance(diet, str) or diet not in {
        "Any", "Vegetarian", "Vegan", "Non-vegetarian", "High protein"
    }:
        raise ValueError("Recipe diet preference is invalid.")
    if not isinstance(difficulty, str) or difficulty not in {
        "Any", "Easy", "Medium", "Hard"
    }:
        raise ValueError("Recipe difficulty preference is invalid.")
    if isinstance(time_limit, bool) or not isinstance(time_limit, int) or not 0 <= time_limit <= 360:
        raise ValueError("Recipe time preference is invalid.")
    return (
        list(dict.fromkeys(allergies)),
        [item.strip().lower() for item in avoid],
        {"diet": diet, "time": time_limit, "diff": difficulty},
    )


def _request_ai_recipe(request, import_video=False):
    try:
        body = _json_body(request)
        allergies, avoid, preferences = _recipe_filters(body)
        if import_video:
            url = body.get("url")
            if not isinstance(url, str) or not url.strip() or len(url) > 500:
                raise ValueError("Enter a valid public YouTube video link.")
            recipe = import_ai_youtube_recipe(url, allergies, avoid, preferences)
        else:
            ingredients = body.get("ingredients")
            if not isinstance(ingredients, list) or not 2 <= len(ingredients) <= 100:
                raise ValueError("Enter at least 2 ingredients to generate a recipe.")
            cleaned_ingredients = []
            for item in ingredients:
                if not isinstance(item, dict):
                    raise ValueError("Recipe ingredients must be objects.")
                cleaned = {
                    "name": _bounded_text(
                        item.get("n"), "Ingredient name", 100
                    ).lower(),
                    "quantity": _bounded_number(
                        item.get("q"), "Ingredient quantity", 0.001, 100000
                    ),
                    "unit": _bounded_text(item.get("u"), "Ingredient unit", 5),
                }
                if cleaned["unit"] not in {"g", "ml", "pc"}:
                    raise ValueError("Ingredient units must be g, ml or pc.")
                if _ingredient_is_blocked(cleaned["name"], allergies, avoid):
                    raise ValueError(
                        "Remove ingredients matching your allergy or avoid settings."
                    )
                cleaned_ingredients.append(cleaned)
            input_diet = _diet_category(
                [{"n": item["name"]} for item in cleaned_ingredients]
            )
            if preferences["diet"] == "Vegan" and input_diet != "vegan":
                raise ValueError(
                    "Remove non-vegan ingredients before generating a recipe."
                )
            if preferences["diet"] == "Vegetarian" and input_diet == "nonveg":
                raise ValueError(
                    "Remove non-vegetarian ingredients before generating a recipe."
                )
            recipe = generate_ai_recipe(
                cleaned_ingredients, allergies, avoid, preferences
            )
    except ValueError as exc:
        return _error(str(exc))
    except AIConfigurationError as exc:
        return _error(str(exc), status=503)
    except AIProviderError as exc:
        return _error(str(exc), status=502)
    return JsonResponse({"recipe": recipe})


@require_POST
def generate_recipe(request):
    return _request_ai_recipe(request)


@require_POST
def import_youtube_recipe(request):
    return _request_ai_recipe(request, import_video=True)
