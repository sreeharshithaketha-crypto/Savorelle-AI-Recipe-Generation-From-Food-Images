# Savorelle

Savorelle is a Django-backed recipe-planning prototype. The frontend is served by
Django, account passwords are hashed by Django, and signed-in workspace data is
stored in the database. Guest workspace data stays in that browser.

## Run locally

From the project directory, in PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python manage.py migrate
python manage.py test
python manage.py runserver
```

Open `http://127.0.0.1:8000/`. Do not open `index.html` directly; the backend
provides the session, CSRF protection, APIs, and static assets.

## Backend and sync

- `POST /api/auth/register/`, `POST /api/auth/login/`, and
  `POST /api/auth/logout/` manage Django sessions.
- `GET /api/auth/me/` reports the current session.
- `GET` and revision-checked `PUT /api/workspace/` load and save inventory,
  allergies, preferences, custom recipes, saved recipes, history, meal plans,
  shopping state, and recipe notes.
- `POST /api/scan/` validates and analyzes an uploaded JPEG, PNG, or WebP image.
  It does not retain the image. When `GEMINI_API_KEY` is configured, Gemini
  identifies a visible dish and suggests visible ingredients; the structured
  result is validated before returning for user review. The model also
  classifies whether the image contains food; non-food images are rejected.
- `POST /api/recipes/generate/` creates a structured recipe from the user's
  ingredients and preferences. `POST /api/youtube/import/` analyzes a public
  YouTube cooking video and extracts its recipe. Both validate the generated
  recipe, apply allergy and avoid filters, and return explicit provider errors
  instead of fabricated results.
- `GET /api/demo-recipes/` serves the 50 illustrative records from `recipes.json`
  for the browse-only sample catalogue. The records have no ingredient quantities
  or verified nutrition, so the app does not use them for recipe matching,
  meal planning, or shopping.

Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/app/apikey),
then set `GEMINI_API_KEY` in the server environment to enable the hosted AI
features. Never put the key in frontend code or commit it. `SAVORELLE_GEMINI_MODEL`
defaults to `gemini-2.5-flash` and can be used to select another compatible
Gemini model. Images and YouTube video links are sent to Google for processing;
Savorelle does not persist uploaded images. Selected allergy and avoid settings
are sent with requests, and matching generated ingredients are rejected.
Visual analysis cannot identify hidden ingredients or guarantee food safety.
Generated quantities and nutrition are estimates, not verified facts. Check
Google's current [Gemini API data-use terms](https://ai.google.dev/gemini-api/terms)
and [pricing](https://ai.google.dev/gemini-api/docs/pricing); usage may incur
charges depending on the account and current plan.

For a local PowerShell session, set the key before starting Django:

```powershell
$env:GEMINI_API_KEY = "your-key"
.\.venv\Scripts\python.exe manage.py runserver
```

The key is effective only for processes started from that PowerShell session.
Restart Django after changing it; do not paste a real key into project files or
chat.

The app automatically saves guest changes in browser storage and signed-in
changes to the Django database. Cross-device sync requires the same hosted
backend and a persistent database. SQLite is suitable for local development;
use a production database and persistent storage for a public deployment.

For deployment, set `SAVORELLE_SECRET_KEY` to a private random value,
`SAVORELLE_DEBUG=0`, and `SAVORELLE_ALLOWED_HOSTS` to the deployment hostnames.
Run migrations and `python manage.py collectstatic`, then configure the host to
serve `/assets/` from `collected-assets`. Do not use the development server as
a public production server.

## Current prototype boundaries

All three AI features require `GEMINI_API_KEY`; without it, they return a
service-unavailable error and do not fall back to simulated results. YouTube
imports work only for public videos. Verify recipe quantities, nutrition and
allergen information; suggestions are not medical or food-safety advice.

## Future ingredient model training

No local detector is trained or included, and the current scan endpoint does
not load a local checkpoint; Gemini vision is required for scan analysis and
non-food rejection. See [training/README.md](./training/README.md) for the
dataset audit and requirements for a future, separately integrated model. The
supplied images are used by tests to exercise image decoding and upload
validation, not as labeled training or accuracy-evaluation data. User scan
uploads are not automatically saved or used for training.
