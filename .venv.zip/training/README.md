# Ingredient detection data

There is no trained model or labeled ingredient dataset in this project yet.
The current scan endpoint uses Gemini vision; a locally trained
checkpoint is not loaded by the running application.
The supplied image archives contain generated dish photographs and collage
crops, not verified ingredient labels. They are useful for testing image
decoding and the scan endpoint, but cannot train or measure an ingredient
detector. The supplied 50 recipe records are illustrative examples without
ingredient quantities or verified nutrition labels. The app exposes them as a
browse-only sample catalogue; they are not used for recipe matching, planning,
or shopping. Tests check data integrity, not recommender accuracy.

The archives remain in the project root. The recipe CSV/JSON also remain there;
the recipe-training bundle duplicates those files and some of the images, so
do not extract it over the other files. To train a detector, provide
photographs you have permission to use, with verified ingredient labels. Do
not include user scan uploads unless those users have separately given
explicit permission for model training.

## Required data

- Choose and freeze an ingredient vocabulary first (for example, `tomato`,
  `onion`, `spinach`). Labels must use these exact names and distinguish
  visually different classes consistently.
- Supply real photographs for each class, including different kitchens,
  cameras, lighting, distances, backgrounds, orientations, packaging, and
  ingredient states (whole, chopped, and cooked if those are in scope).
- Use one image per source scene where possible. Avoid near-duplicate photos
  across training and evaluation splits.
- Draw a bounding box around each visible ingredient and label it with its
  class. This project uses the Ultralytics YOLO detection label format:
  `class_id x_center y_center width height`, with coordinates normalized from
  0 to 1. If an image has no target ingredient, use an empty label file.
- Split by source session or kitchen, not by near-identical frames. A practical
  starting split is 70% training, 15% validation, and 15% held-out testing.
  Include enough varied images per class to represent its real deployment
  conditions; a few examples per ingredient will not provide reliable
  detection.
- Keep a record of each dataset's source, license/consent, label vocabulary,
  and split. Exclude personal or sensitive information from images.

Example directory layout:

```text
datasets/ingredients/
  images/
    train/
    val/
    test/
  labels/
    train/
    val/
    test/
  data.yaml
```

`data.yaml` must declare the three image paths and a `names` list whose
zero-based order exactly matches the label class IDs. For example:

```yaml
path: datasets/ingredients
train: images/train
val: images/val
test: images/test
names:
  0: tomato
  1: onion
  2: spinach
```

This example vocabulary is illustrative; decide the actual classes before
labeling.

## Train

Install the optional training dependency and run from the project directory:

```powershell
pip install -r requirements-training.txt
python training/train.py --data datasets/ingredients/data.yaml --weights yolo11n.pt
```

The first run may download the initial weights. The best checkpoint is copied
to `models/ingredient_detector.pt`. This training script is preparation for a
future detector integration; the current Django scan endpoint does not load
that checkpoint and requires Gemini vision. Keep trained weights out of source
control unless their size and redistribution license have been reviewed.

After training, evaluate per-class precision, recall, and mAP on the untouched
test split, and manually inspect false positives and missed items across
different devices. Quantities and weights cannot be reliably inferred from
bounding boxes alone; users must continue to review and correct scan results.
Image-only models also cannot establish hidden ingredients, cross-contact, or
whether a food is safe for a particular allergy.
