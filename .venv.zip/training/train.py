import argparse
import shutil
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Train Savorelle's ingredient detector.")
    parser.add_argument("--data", required=True, help="Path to an Ultralytics data.yaml file.")
    parser.add_argument("--weights", default="yolo11n.pt", help="Initial detector weights.")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--project", default="training/runs")
    parser.add_argument("--name", default="ingredients")
    args = parser.parse_args()

    from ultralytics import YOLO

    model = YOLO(args.weights)
    result = model.train(
        data=args.data,
        epochs=args.epochs,
        imgsz=args.imgsz,
        project=args.project,
        name=args.name,
    )
    best = Path(result.save_dir) / "weights" / "best.pt"
    if not best.is_file():
        raise FileNotFoundError(f"Training did not produce the expected checkpoint: {best}")
    destination = Path("models") / "ingredient_detector.pt"
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(best, destination)
    print(f"Saved trained detector to {destination.resolve()}")


if __name__ == "__main__":
    main()
